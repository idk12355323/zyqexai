import crypto from 'crypto';
export const config = { api: { bodyParser: false } };

function send(res, status, body) { res.status(status).setHeader('Content-Type', 'application/json'); return res.end(JSON.stringify(body)); }
async function rawBody(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
  return Buffer.concat(chunks).toString('utf8');
}
function verifyStripeSignature(payload, signature, secret) {
  if (!signature || !secret) return false;
  const parts = signature.split(',').reduce((acc, part) => { const [k, v] = part.split('='); (acc[k] ||= []).push(v); return acc; }, {});
  const timestamp = parts.t?.[0], signatures = parts.v1 || [];
  if (!timestamp || !signatures.length) return false;
  const age = Math.abs(Math.floor(Date.now() / 1000) - Number(timestamp));
  if (!Number.isFinite(age) || age > 300) return false;
  const expected = crypto.createHmac('sha256', secret).update(`${timestamp}.${payload}`).digest('hex');
  return signatures.some(sig => { try { return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(sig)); } catch (_) { return false; } });
}
async function updatePremium(userId, paymentIntentId) {
  const url = process.env.SUPABASE_URL || 'https://shvchlduqvqmvvrdaddi.supabase.co';
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!key) throw new Error('SUPABASE_SERVICE_ROLE_KEY is missing.');
  const response = await fetch(`${url}/rest/v1/profiles?id=eq.${encodeURIComponent(userId)}`, { method: 'PATCH', headers: { apikey: key, Authorization: `Bearer ${key}`, 'Content-Type': 'application/json', Prefer: 'return=minimal' }, body: JSON.stringify({ is_premium: true, premium_purchased_at: new Date().toISOString(), stripe_payment_intent_id: paymentIntentId || null }) });
  if (!response.ok) throw new Error(`Supabase premium update failed: ${response.status}`);
}
export default async function handler(req, res) {
  if (req.method !== 'POST') return send(res, 405, { error: 'Method Not Allowed' });
  const payload = await rawBody(req);
  const signature = req.headers['stripe-signature'];
  if (!verifyStripeSignature(payload, signature, process.env.STRIPE_WEBHOOK_SECRET)) return send(res, 400, { error: 'Invalid signature.' });
  try {
    const stripeEvent = JSON.parse(payload);
    if (stripeEvent.type === 'checkout.session.completed') {
      const session = stripeEvent.data.object;
      if (session.payment_status === 'paid' && session.metadata?.plan === 'zyqex_premium' && session.metadata?.user_id) await updatePremium(session.metadata.user_id, session.payment_intent);
    }
    return send(res, 200, { received: true });
  } catch (error) { return send(res, 500, { error: error.message || 'Webhook error.' }); }
}
