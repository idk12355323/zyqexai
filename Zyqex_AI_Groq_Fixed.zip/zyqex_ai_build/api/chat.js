const SYSTEM_PROMPT = `You are Zyqex AI, a helpful, friendly general-purpose AI assistant. Give clear, accurate, useful answers. Be concise when the question is simple and more detailed when needed. Do not mention internal implementation details unless asked. You can help with writing, coding, explanations, ideas, planning, and image understanding.`;

function dataUrlToInlineData(dataUrl) {
  if (typeof dataUrl !== 'string' || !dataUrl.startsWith('data:image/')) return null;
  const match = dataUrl.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/s);
  if (!match) return null;
  return { mimeType: match[1], data: match[2] };
}
function send(res, status, body) {
  res.status(status).setHeader('Content-Type', 'application/json');
  res.setHeader('Cache-Control', 'no-store');
  return res.end(JSON.stringify(body));
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return send(res, 405, { error: 'Method Not Allowed' });
  try {
    const auth = req.headers.authorization || '';
    const supabaseUrl = process.env.SUPABASE_URL || 'https://shvchlduqvqmvvrdaddi.supabase.co';
    const supabaseAnonKey = process.env.SUPABASE_ANON_KEY || process.env.SUPABASE_PUBLISHABLE_KEY;
    if (!auth.startsWith('Bearer ') || !supabaseUrl || !supabaseAnonKey) return send(res, 401, { error: 'Login required.' });

    const userResponse = await fetch(`${supabaseUrl}/auth/v1/user`, { headers: { apikey: supabaseAnonKey, Authorization: auth } });
    if (!userResponse.ok) return send(res, 401, { error: 'Your session is invalid or expired.' });

    const body = req.body || {};
    const message = String(body.message || '').trim();
    const images = Array.isArray(body.images) ? body.images.slice(0, 3) : [];
    const history = Array.isArray(body.history) ? body.history.slice(-12) : [];
    if (!message && images.length === 0) return send(res, 400, { error: 'Please enter a message.' });

    const apiKey = process.env.GROQ_API_KEY;
    const textModel = process.env.GROQ_MODEL || 'openai/gpt-oss-120b';
    const visionModel = 'meta-llama/llama-4-scout-17b-16e-instruct';
    if (!apiKey) return send(res, 503, { error: 'The AI service is not connected yet. Add GROQ_API_KEY in Vercel environment variables, then redeploy.' });

    const messages = [{ role: 'system', content: SYSTEM_PROMPT }];
    for (const item of history) {
      if (!item || !['user', 'assistant'].includes(item.role) || !item.content) continue;
      messages.push({ role: item.role, content: String(item.content).slice(0, 12000) });
    }

    let userContent = message.slice(0, 20000);
    const validImages = [];
    for (const image of images) {
      if (typeof image === 'string' && image.startsWith('data:image/')) validImages.push(image);
    }
    if (validImages.length) {
      userContent = [
        ...(message ? [{ type: 'text', text: message.slice(0, 20000) }] : []),
        ...validImages.map(url => ({ type: 'image_url', image_url: { url } }))
      ];
    }
    messages.push({ role: 'user', content: userContent });

    const endpoint = 'https://api.groq.com/openai/v1/chat/completions';
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: validImages.length ? visionModel : textModel,
        messages,
        max_completion_tokens: 2000
      })
    });
    const data = await response.json();
    if (!response.ok) {
      const details = data?.error?.message || 'The Groq AI service returned an error.';
      return send(res, response.status || 503, { error: `Groq request failed: ${details}` });
    }
    const reply = data?.choices?.[0]?.message?.content?.trim() || 'I could not generate a response.';
    return send(res, 200, { reply });
  } catch (error) { return send(res, 500, { error: error.message || 'Unexpected server error.' }); }
}
