function send(res, status, body) { res.status(status).setHeader('Content-Type', 'application/json'); return res.end(JSON.stringify(body)); }

export default async function handler(req, res) {
  if (req.method !== 'POST') return send(res, 405, { error: 'Method Not Allowed' });
  const auth = req.headers.authorization || '';
  const supabaseUrl = process.env.SUPABASE_URL || 'https://shvchlduqvqmvvrdaddi.supabase.co';
  const supabaseAnonKey = process.env.SUPABASE_ANON_KEY || process.env.SUPABASE_PUBLISHABLE_KEY;
  const stripeSecret = process.env.STRIPE_SECRET_KEY || process.env.stripe_secret_key || process.env.STRIPE_API_KEY || process.env.STRIPE_RESTRICTED_KEY || process.env.stripeSecretKey;
  const siteUrl = process.env.SITE_URL || `https://${req.headers.host || ''}`;
  if (!auth.startsWith('Bearer ')) return send(res, 401, { error: 'Please log in before buying Premium.' });
  if (!stripeSecret) return send(res, 503, { error: 'Premium checkout is not configured. Add STRIPE_SECRET_KEY to Vercel environment variables and redeploy.' });
  if (!supabaseUrl || !supabaseAnonKey) return send(res, 503, { error: 'Supabase server configuration is missing.' });
  try {
    const userRes = await fetch(`${supabaseUrl}/auth/v1/user`, { headers: { apikey: supabaseAnonKey, Authorization: auth } });
    if (!userRes.ok) return send(res, 401, { error: 'Your login session has expired. Please log in again.' });
    const user = await userRes.json();
    const params = new URLSearchParams();
    params.set('mode', 'payment');
    params.set('success_url', `${siteUrl}/?premium=success`);
    params.set('cancel_url', `${siteUrl}/?premium=cancelled`);
    params.set('line_items[0][quantity]', '1');
    params.set('line_items[0][price_data][currency]', 'gbp');
    params.set('line_items[0][price_data][unit_amount]', '1000');
    params.set('line_items[0][price_data][product_data][name]', 'Zyqex Premium');
    params.set('line_items[0][price_data][product_data][description]', 'One-time purchase: unlimited Zyqex AI messages and image messages.');
    params.set('customer_email', user.email || '');
    params.set('metadata[user_id]', user.id);
    params.set('metadata[plan]', 'zyqex_premium');
    params.set('payment_intent_data[metadata][user_id]', user.id);
    params.set('payment_intent_data[metadata][plan]', 'zyqex_premium');
    const stripeRes = await fetch('https://api.stripe.com/v1/checkout/sessions', { method: 'POST', headers: { Authorization: `Bearer ${stripeSecret}`, 'Content-Type': 'application/x-www-form-urlencoded' }, body: params.toString() });
    const data = await stripeRes.json();
    if (!stripeRes.ok) return send(res, stripeRes.status === 401 ? 401 : 500, { error: `Stripe error: ${data?.error?.message || 'Stripe could not create checkout.'}` });
    return send(res, 200, { url: data.url });
  } catch (error) { return send(res, 500, { error: error.message || 'Could not start checkout.' }); }
}
