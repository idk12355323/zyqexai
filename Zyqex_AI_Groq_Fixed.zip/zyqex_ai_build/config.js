/*
  Zyqex AI account setup.
  Replace the two values below with your Supabase project URL and anon/publishable key.
  NEVER put a Supabase service_role key here.
*/
window.ZYQEX_CONFIG = {
  SUPABASE_URL: "https://shvchlduqvqmvvrdaddi.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_Blq5G8YjUWbtkncen8fG8w_y7iQG_ey"
};
