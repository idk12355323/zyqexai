# Zyqex AI - Vercel build

Vercel-ready Zyqex AI with API routes for Groq chat, Stripe Checkout, and Stripe webhook handling.

Required Vercel environment variables:
- GROQ_API_KEY
- STRIPE_SECRET_KEY
- SUPABASE_URL
- SUPABASE_ANON_KEY (or SUPABASE_PUBLISHABLE_KEY)
- SUPABASE_SERVICE_ROLE_KEY
- STRIPE_WEBHOOK_SECRET (only needed for automatic Premium activation via webhook)
- SITE_URL (optional; otherwise the current Vercel host is used)
