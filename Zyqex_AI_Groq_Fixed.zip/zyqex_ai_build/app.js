(() => {
  'use strict';

  const FREE_MESSAGES = 30;
  const FREE_IMAGES = 3;
  const MAX_IMAGES_PER_MESSAGE = 10;
  let currentUser = null;
  let currentProfile = null;
  let currentChatId = null;
  let pendingImages = [];
  let authMode = 'login';
  let supabaseClient = null;
  let conversation = [];
  let chatDataCache = [];
  let listening = false;

  const $ = (id) => document.getElementById(id);
  const cfg = () => window.ZYQEX_CONFIG || {};

  function getSupabase() {
    if (supabaseClient) return supabaseClient;
    if (window.supabase?.createClient && cfg().SUPABASE_URL && cfg().SUPABASE_ANON_KEY) {
      try { supabaseClient = window.supabase.createClient(cfg().SUPABASE_URL, cfg().SUPABASE_ANON_KEY); } catch (e) { console.error(e); }
    }
    return supabaseClient;
  }

  function isPremium() { return !!currentProfile?.is_premium; }
  function titleFor(text) { return (text || 'New chat').replace(/\s+/g, ' ').trim().slice(0, 48) || 'New chat'; }

  function localKey() { return `zyqex_chats_${currentUser?.id || 'guest'}`; }
  function cacheConversation() {
    if (!currentChatId || !conversation.length) return;
    try {
      const all = JSON.parse(localStorage.getItem(localKey()) || '{}');
      all[currentChatId] = { id: currentChatId, title: all[currentChatId]?.title || titleFor(conversation.find(m => m.role === 'user')?.content), updated_at: Date.now(), messages: conversation.slice(-100) };
      localStorage.setItem(localKey(), JSON.stringify(all));
    } catch (_) {}
  }
  function clearChatCache() { try { localStorage.removeItem(localKey()); } catch (_) {} }

  function showToast(text) {
    const toast = $('toast'); if (!toast) return;
    toast.textContent = text; toast.classList.remove('hidden');
    clearTimeout(showToast.timer); showToast.timer = setTimeout(() => toast.classList.add('hidden'), 2600);
  }

  function updateAccountUI() {
    const logged = !!currentUser;
    const name = currentProfile?.display_name || currentUser?.email?.split('@')[0] || 'Log in';
    if ($('accountLabel')) $('accountLabel').textContent = logged ? name : 'Log in';
    if ($('accountSub')) $('accountSub').textContent = logged ? (isPremium() ? 'Zyqex Premium' : currentUser.email || '') : 'Sign in to Zyqex AI';
    if ($('accountAvatar')) $('accountAvatar').textContent = name.slice(0, 1).toUpperCase();
    if ($('profileAvatar')) $('profileAvatar').textContent = name.slice(0, 1).toUpperCase();
    if ($('premiumBadge')) $('premiumBadge').classList.toggle('hidden', !isPremium());
    if ($('usage')) $('usage').textContent = isPremium() ? '∞ unlimited messages • ∞ unlimited images' : `${FREE_MESSAGES} messages • ${FREE_IMAGES} images daily`;
  }

  function updateSendState() {
    const input = $('input'), send = $('sendBtn'); if (!input || !send) return;
    send.disabled = send.dataset.busy === 'true' || (!input.value.trim() && !pendingImages.length);
  }

  function setBusy(busy) {
    const input = $('input'), send = $('sendBtn');
    if (send) send.dataset.busy = busy ? 'true' : 'false';
    if (input) input.disabled = busy;
    if ($('attachBtn')) $('attachBtn').disabled = busy;
    if ($('imageInput')) $('imageInput').disabled = busy;
    updateSendState();
  }

  function showWelcome() {
    const messages = $('messages'); if (!messages) return;
    messages.innerHTML = `<div id="welcome" class="welcome">
      <div class="welcome-mark"><span>✦</span></div>
      <h1>What can I help with?</h1>
      <p>Ask anything, write, brainstorm, analyze images, or turn an idea into a plan.</p>
      <div class="prompt-grid">
        <button data-prompt="Explain quantum computing in a simple way"><span>✧</span><strong>Explain something</strong><small>Break down a difficult topic</small></button>
        <button data-prompt="Help me write a professional email"><span>⌁</span><strong>Help me write</strong><small>Create or improve text</small></button>
        <button data-prompt="Give me 10 creative ideas for a new project"><span>✦</span><strong>Brainstorm ideas</strong><small>Explore something new</small></button>
        <button data-prompt="Make a useful plan for my week"><span>✓</span><strong>Make a plan</strong><small>Turn goals into steps</small></button>
      </div></div>`;
    messages.querySelectorAll('[data-prompt]').forEach(btn => btn.addEventListener('click', () => {
      $('input').value = btn.dataset.prompt || ''; $('input').focus(); updateSendState();
    }));
  }

  function addMessage(text, who, imageCount = 0) {
    const messages = $('messages'); if (!messages) return;
    $('welcome')?.remove();
    const wrap = document.createElement('div'); wrap.className = `message ${who}`;
    const bubble = document.createElement('div'); bubble.className = 'bubble';
    bubble.textContent = text || (imageCount ? `Image${imageCount > 1 ? 's' : ''} uploaded` : '');
    if (imageCount) { const note = document.createElement('small'); note.className = 'image-note'; note.textContent = `${imageCount} image${imageCount === 1 ? '' : 's'} attached`; bubble.append(document.createElement('br'), note); }
    wrap.appendChild(bubble);

    const actions = document.createElement('div'); actions.className = 'message-actions';
    const addAction = (label, symbol, fn) => {
      const b = document.createElement('button'); b.className = 'message-action'; b.type = 'button'; b.setAttribute('aria-label', label); b.title = label; b.textContent = symbol; b.addEventListener('click', fn); actions.appendChild(b);
    };
    if (who === 'assistant') {
      addAction('Copy response', '▢', () => copyText(text || ''));
      addAction('Helpful', '♡', () => showToast('Thanks — feedback received.'));
      addAction('Not helpful', '⌁', () => showToast('Thanks — feedback received.'));
      addAction('Regenerate response', '↻', () => regenerateLast());
    } else {
      addAction('Edit message', '✎', () => { $('input').value = text || ''; $('input').focus(); updateSendState(); });
      addAction('Copy message', '▢', () => copyText(text || ''));
    }
    wrap.appendChild(actions); messages.appendChild(wrap); messages.scrollTop = messages.scrollHeight; return wrap;
  }

  async function copyText(text) {
    try { await navigator.clipboard.writeText(text); showToast('Copied to clipboard'); }
    catch (_) { showToast('Copy is unavailable in this browser'); }
  }

  async function regenerateLast() {
    if (!currentUser || $('sendBtn')?.dataset.busy === 'true') return;
    const lastUser = [...conversation].reverse().find(m => m.role === 'user');
    if (!lastUser) { showToast('There is no response to regenerate yet.'); return; }
    setBusy(true); let typing = null;
    try {
      conversation = conversation.filter((m, i) => !(m.role === 'assistant' && i === conversation.length - 1));
      const assistantNodes = $('messages')?.querySelectorAll('.message.assistant');
      assistantNodes?.[assistantNodes.length - 1]?.remove();
      typing = addTyping();
      const reply = await callAI(lastUser.content, []);
      typing?.remove(); addMessage(reply, 'assistant');
      conversation.push({ role:'assistant', content:reply });
      await saveMessage('assistant', reply, 0); await loadChats();
    } catch (err) { typing?.remove(); addMessage(err.message || 'Could not regenerate the response.', 'assistant'); }
    finally { setBusy(false); updateSendState(); }
  }

  function addTyping() {
    const messages = $('messages'); if (!messages) return null;
    const wrap = document.createElement('div'); wrap.className = 'message assistant'; wrap.id = 'typingMessage';
    const bubble = document.createElement('div'); bubble.className = 'bubble typing'; bubble.innerHTML = '<span>Zyqex AI is thinking</span><span class="thinking-dots" aria-hidden="true"><i></i><i></i><i></i></span>';
    wrap.appendChild(bubble); messages.appendChild(wrap); messages.scrollTop = messages.scrollHeight; return wrap;
  }

  function openAuth(mode = 'login') {
    authMode = mode; $('authModal')?.classList.remove('hidden');
    $('authTitle').textContent = mode === 'login' ? 'Log in to Zyqex AI' : 'Create your Zyqex AI account';
    $('authSubtitle').textContent = mode === 'login' ? 'Sign in to save chats and use Zyqex AI.' : 'Create an account and start chatting.';
    $('authSubmit').textContent = mode === 'login' ? 'Log in' : 'Sign up';
    $('authSwitch').textContent = mode === 'login' ? 'Need an account? Sign up' : 'Already have an account? Log in';
    $('nameField').classList.toggle('hidden', mode === 'login');
    $('authMessage').textContent = getSupabase() ? '' : 'Supabase is not configured.';
    setTimeout(() => $('authEmail')?.focus(), 50);
  }
  function closeAuth() { $('authModal')?.classList.add('hidden'); }

  async function handleAuth(e) {
    e.preventDefault(); const sb = getSupabase(); if (!sb) return;
    const email = $('authEmail').value.trim(), password = $('authPassword').value;
    $('authSubmit').disabled = true; $('authMessage').textContent = 'Working…';
    try {
      if (authMode === 'signup') {
        const displayName = $('authName').value.trim() || email.split('@')[0];
        const { data, error } = await sb.auth.signUp({ email, password, options: { data: { display_name: displayName } } });
        if (error) throw error;
        if (data.session) closeAuth(); else $('authMessage').textContent = 'Account created. Check your email to confirm your account.';
      } else {
        const { error } = await sb.auth.signInWithPassword({ email, password }); if (error) throw error; closeAuth();
      }
    } catch (err) { $('authMessage').textContent = err.message || 'Something went wrong.'; }
    finally { $('authSubmit').disabled = false; }
  }

  async function loadProfile() {
    const sb = getSupabase(); if (!sb || !currentUser) return;
    const { data, error } = await sb.from('profiles').select('display_name,is_premium,premium_purchased_at').eq('id', currentUser.id).maybeSingle();
    if (!error) currentProfile = data || { display_name: currentUser.email?.split('@')[0], is_premium: false };
    updateAccountUI();
  }

  function renderChatList(filter = '') {
    const list = $('chatList'); if (!list) return; list.innerHTML = '';
    const q = (filter || '').trim().toLowerCase();
    const data = chatDataCache.filter(chat => !q || String(chat.title || 'New chat').toLowerCase().includes(q));
    if (!data.length) { const empty = document.createElement('div'); empty.className='chat-empty'; empty.textContent=q ? 'No matching chats' : (currentUser ? 'Your saved chats will appear here' : 'Log in to save your chats'); list.appendChild(empty); return; }
    data.forEach(chat => {
      const item=document.createElement('button'); item.className=`chat-item${chat.id===currentChatId?' active':''}`;
      item.innerHTML=`<span class="chat-icon">◌</span><span>${escapeHtml(chat.title || 'New chat')}</span>`;
      item.addEventListener('click',()=>openChat(chat.id)); list.appendChild(item);
    });
  }

  async function loadChats() {
    if (!currentUser) { chatDataCache=[]; renderChatList(); return; }
    const sb=getSupabase(); let data=[];
    if(sb){ const result=await sb.from('chats').select('id,title,updated_at').order('updated_at',{ascending:false}).limit(50); data=result.data||[]; }
    try{
      const cached=JSON.parse(localStorage.getItem(localKey())||'{}'); const localChats=Object.values(cached); const seen=new Set(data.map(c=>c.id));
      for(const chat of localChats) if(!seen.has(chat.id)) data.push(chat);
      data.sort((a,b)=>new Date(b.updated_at)-new Date(a.updated_at));
    }catch(_){}
    chatDataCache=data; renderChatList($('chatSearch')?.value || '');
  }

  function escapeHtml(text) { const d = document.createElement('div'); d.textContent = text || ''; return d.innerHTML; }

  async function openChat(id) {
    const sb = getSupabase(); if (!currentUser) return;
    let rows = [];
    if (sb) {
      const result = await sb.from('messages').select('role,content,image_count,created_at').eq('chat_id', id).order('created_at', { ascending: true });
      if (!result.error) rows = result.data || [];
    }
    if (!rows.length) {
      try {
        const cached = JSON.parse(localStorage.getItem(localKey()) || '{}')[id];
        rows = (cached?.messages || []).map(m => ({ ...m, image_count: m.image_count || 0 }));
      } catch (_) {}
    }
    currentChatId = id; conversation = []; pendingImages = []; $('preview').innerHTML = ''; $('input').value = '';
    $('messages').innerHTML = '';
    if (!rows.length) { showWelcome(); }
    rows.forEach(row => { addMessage(row.content, row.role, row.image_count || 0); if (row.content) conversation.push({ role: row.role, content: row.content }); });
    cacheConversation();
    await loadChats();
  }

  async function newChat() {
    // Every conversation is persisted as messages are sent. This final pass makes the
    // current chat safe before switching to a fresh conversation.
    cacheConversation();
    if (currentChatId && currentUser) {
      const sb = getSupabase();
      if (sb && conversation.length) {
        const firstUser = conversation.find(m => m.role === 'user');
        if (firstUser) await sb.from('chats').update({ title: titleFor(firstUser.content), updated_at: new Date().toISOString() }).eq('id', currentChatId).eq('user_id', currentUser.id);
      }
    }
    currentChatId = null; conversation = []; pendingImages = []; $('preview').innerHTML = ''; $('input').value = ''; showWelcome(); updateSendState(); await loadChats(); $('input').focus();
  }

  async function ensureChat(title) {
    if (currentChatId) return currentChatId;
    if (!currentUser) return null;
    const sb = getSupabase();
    if (sb) {
      const { data, error } = await sb.from('chats').insert({ user_id: currentUser.id, title: titleFor(title) }).select('id').single();
      if (!error && data?.id) {
        currentChatId = data.id;
        cacheConversation();
        await loadChats();
        return currentChatId;
      }
      console.warn('Supabase chat insert failed:', error);
      showToast(`Cloud save failed: ${error?.message || 'check the Supabase SQL setup'}`);
    }

    // Never lose the conversation just because the cloud database is not ready.
    // A local UUID keeps the chat usable and persisted in this browser.
    currentChatId = (globalThis.crypto?.randomUUID ? crypto.randomUUID() : `local-${Date.now()}-${Math.random().toString(36).slice(2)}`);
    cacheConversation();
    await loadChats();
    return currentChatId;
  }

  async function saveMessage(role, content, imageCount = 0) {
    const sb = getSupabase();
    if (!currentUser || !currentChatId) return false;
    if (sb && !String(currentChatId).startsWith('local-')) {
      const { error } = await sb.from('messages').insert({ chat_id: currentChatId, user_id: currentUser.id, role, content: content || '', image_count: imageCount });
      if (error) {
        console.warn('Supabase message insert failed:', error);
        cacheConversation();
        showToast(`Saved locally. Cloud save failed: ${error.message || 'check Supabase'}`);
        return false;
      }
    }
    cacheConversation();
    return true;
  }

  async function consumeUsage(imageCount) {
    if (isPremium()) return { allowed: true, message_count: null, image_count: null, reason: 'premium' };
    const sb = getSupabase(); if (!sb) return { allowed: false, reason: 'not_authenticated' };
    const { data, error } = await sb.rpc('consume_usage', { p_image_count: imageCount }); if (error) throw error;
    return Array.isArray(data) ? (data[0] || {}) : (data || {});
  }

  async function callAI(message, images) {
    const sb = getSupabase(); const { data } = await sb.auth.getSession(); const token = data.session?.access_token;
    if (!token) throw new Error('Your login session has expired. Please log in again.');
    const response = await fetch('/api/chat', { method:'POST', headers:{'Content-Type':'application/json','Authorization':`Bearer ${token}`}, body:JSON.stringify({message,images,history:conversation.slice(-12)}) });
    let body={}; try{body=await response.json()}catch(_){ }
    if (!response.ok) throw new Error(body.error || 'Zyqex AI could not generate a response.'); return body.reply || 'I could not generate a response.';
  }

  async function send() {
    const input=$('input'); if (!input || $('sendBtn').dataset.busy==='true') return;
    const text=input.value.trim(), images=pendingImages.slice(0,MAX_IMAGES_PER_MESSAGE), imageCount=images.length; if(!text&&!imageCount)return;
    if(!currentUser){openAuth('login');return;}
    setBusy(true); let typing=null;
    try{
      const usage=await consumeUsage(imageCount);
      if(!usage.allowed){ const reason=usage.reason==='message_limit'?`Free plan limit reached: ${FREE_MESSAGES} messages today.`:usage.reason==='image_limit'?`Free plan limit reached: ${FREE_IMAGES} images today.`:'Please log in again.'; addMessage(reason,'assistant'); return; }
      const userText=text||'Please describe the attached image(s).'; addMessage(text||'Image uploaded','user',imageCount); conversation.push({role:'user',content:userText}); input.value=''; pendingImages=[]; $('preview').innerHTML=''; updateSendState();
      await ensureChat(text||'Image chat');
      await saveMessage('user',userText,imageCount);
      typing=addTyping();
      const reply=await callAI(userText,images); typing?.remove(); addMessage(reply,'assistant'); conversation.push({role:'assistant',content:reply}); await saveMessage('assistant',reply,0); await loadChats();
    }catch(err){typing?.remove();addMessage(err.message||'Something went wrong.','assistant')}finally{setBusy(false);input.focus();updateSendState()}
  }

  function handleImages(e){
    const files=[...(e.target.files||[])].filter(f=>f.type.startsWith('image/')); const allowed=Math.min(files.length,MAX_IMAGES_PER_MESSAGE-pendingImages.length);
    if(files.length>allowed) showToast(`You can attach up to ${MAX_IMAGES_PER_MESSAGE} images to one message.`);
    files.slice(0,allowed).forEach(file=>{const reader=new FileReader();reader.onload=()=>{pendingImages.push(reader.result);const img=document.createElement('img');img.src=reader.result;img.alt='Image preview';$('preview').appendChild(img);updateSendState()};reader.readAsDataURL(file)});e.target.value='';
  }

  function toggleTheme(){document.body.classList.toggle('light');localStorage.setItem('zyqex_light',document.body.classList.contains('light')?'true':'false')}
  function openAccount(){if(!currentUser){openAuth('login');return}$('profileName').textContent=currentProfile?.display_name||currentUser.email?.split('@')[0]||'Zyqex user';$('profileEmail').textContent=currentUser.email||'';$('displayName').value=currentProfile?.display_name||'';$('accountModal').classList.remove('hidden')}

  async function saveProfile(){const sb=getSupabase();if(!sb||!currentUser)return;const displayName=$('displayName').value.trim()||currentUser.email?.split('@')[0]||'Zyqex user';const {error}=await sb.from('profiles').update({display_name:displayName}).eq('id',currentUser.id);if(error){showToast(error.message);return}currentProfile={...(currentProfile||{}),display_name:displayName};updateAccountUI();$('accountModal').classList.add('hidden')}
  async function logout(){cacheConversation();const sb=getSupabase();if(sb)await sb.auth.signOut();currentUser=null;currentProfile=null;currentChatId=null;conversation=[];$('accountModal').classList.add('hidden');updateAccountUI();$('chatList').innerHTML='';showWelcome()}

  function openPremium(){ $('premiumMessage').textContent=''; $('premiumModal').classList.remove('hidden'); }
  async function buyPremium(){
    if(!currentUser){closeModal('premiumModal');openAuth('login');return;}
    if(isPremium()){ $('premiumMessage').textContent='You already have Zyqex Premium.'; return; }
    const sb=getSupabase(); const {data}=await sb.auth.getSession(); const token=data.session?.access_token;
    $('buyPremium').disabled=true; $('premiumMessage').textContent='Opening secure checkout…';
    try{
      const response=await fetch('/api/create-checkout',{method:'POST',headers:{Authorization:`Bearer ${token}`}});let body={};try{body=await response.json()}catch(_){ }
      if(!response.ok)throw new Error(body.error||'Checkout is not configured yet.');
      if(body.url) window.location.href=body.url; else throw new Error('Checkout URL was not returned.');
    }catch(err){$('premiumMessage').textContent=err.message||'Could not start checkout.';}
    finally{$('buyPremium').disabled=false}
  }
  function closeModal(id){$(id)?.classList.add('hidden')}

  function setupVoice() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) { showToast('Voice input is not supported in this browser.'); return; }
    if (listening) { listening = false; try { window.__zyqexRecognition?.stop(); } catch (_) {} return; }
    const recognition = new SpeechRecognition(); window.__zyqexRecognition = recognition; recognition.lang='en-GB'; recognition.interimResults=true; recognition.continuous=false; listening=true; $('voiceBtn')?.classList.add('recording');
    recognition.onresult=(event)=>{ let transcript=''; for(let i=event.resultIndex;i<event.results.length;i++) transcript+=event.results[i][0].transcript; if($('input')) $('input').value=transcript; updateSendState(); };
    recognition.onerror=()=>{listening=false;$('voiceBtn')?.classList.remove('recording');showToast('Voice input stopped.');};
    recognition.onend=()=>{listening=false;$('voiceBtn')?.classList.remove('recording');updateSendState();};
    recognition.start();
  }

  function openShare() {
    const title = chatDataCache.find(c=>c.id===currentChatId)?.title || 'Zyqex AI chat';
    const text = `Zyqex AI — ${title}`;
    if(navigator.share) navigator.share({title:'Zyqex AI',text}).catch(()=>{});
    else copyText(window.location.href).then(()=>showToast('Chat link copied'));
  }

  function init(){
    if(window.__ZYQEX_INITIALIZED__)return; window.__ZYQEX_INITIALIZED__=true;
    $('sendBtn')?.addEventListener('click',send);
    $('input')?.addEventListener('paste',()=>setTimeout(updateSendState,0));
    document.addEventListener('keydown',e=>{
      if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();newChat();}
      if((e.ctrlKey||e.metaKey)&&e.key==='/'){e.preventDefault();$('searchChatsBtn')?.click();}
      if(e.key==='Escape'){ $('modelMenu')?.classList.add('hidden'); $('plusMenu')?.classList.add('hidden'); }
    });
    $('input')?.addEventListener('input',()=>{const el=$('input');el.style.height='auto';el.style.height=Math.min(el.scrollHeight,180)+'px';updateSendState()});
    $('input')?.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send()}});
    $('newChat')?.addEventListener('click',newChat);
    $('themeBtn')?.addEventListener('click',toggleTheme); $('modalTheme')?.addEventListener('click',toggleTheme);
    $('settingsBtn')?.addEventListener('click',()=>{$('settingsModal').classList.remove('hidden')});
    $('settingsPremium')?.addEventListener('click',()=>{closeModal('settingsModal');openPremium()});
    $('settingsAppearance')?.addEventListener('click',()=>showToast('Appearance controls are in this section.'));
    $('settingsAccount')?.addEventListener('click',()=>{closeModal('settingsModal');openAccount()});
    $('premiumBtn')?.addEventListener('click',openPremium); $('topPremiumBtn')?.addEventListener('click',openPremium); $('accountPremium')?.addEventListener('click',()=>{closeModal('accountModal');openPremium()}); $('buyPremium')?.addEventListener('click',buyPremium);
    $('attachBtn')?.addEventListener('click',()=>{$('plusMenu')?.classList.toggle('hidden')});
    $('plusImages')?.addEventListener('click',()=>{ $('plusMenu')?.classList.add('hidden'); if(!currentUser){openAuth('login');return;} $('imageInput')?.click(); });
    $('plusVoice')?.addEventListener('click',()=>{$('plusMenu')?.classList.add('hidden');setupVoice()});
    $('voiceBtn')?.addEventListener('click',setupVoice); $('imageInput')?.addEventListener('change',handleImages);
    $('menuBtn')?.addEventListener('click',()=>{$('sidebar').classList.add('open');$('sidebarBackdrop').classList.remove('hidden');document.body.classList.add('menu-open')});
    $('collapseBtn')?.addEventListener('click',()=>{$('sidebar').classList.remove('open');$('sidebarBackdrop').classList.add('hidden');document.body.classList.remove('menu-open')});
    $('sidebarBackdrop')?.addEventListener('click',()=>{$('sidebar').classList.remove('open');$('sidebarBackdrop').classList.add('hidden');document.body.classList.remove('menu-open')});
    $('accountBtn')?.addEventListener('click',openAccount); $('mobileAccountBtn')?.addEventListener('click',openAccount);
    $('closeAccount')?.addEventListener('click',()=>closeModal('accountModal')); $('saveProfile')?.addEventListener('click',saveProfile); $('logoutBtn')?.addEventListener('click',logout);
    $('closeAuth')?.addEventListener('click',closeAuth); $('authForm')?.addEventListener('submit',handleAuth); $('authSwitch')?.addEventListener('click',()=>openAuth(authMode==='login'?'signup':'login'));
    $('closeSettings')?.addEventListener('click',()=>closeModal('settingsModal')); $('closePremium')?.addEventListener('click',()=>closeModal('premiumModal'));
    $('shareBtn')?.addEventListener('click',openShare);
    $('modelBtn')?.addEventListener('click',()=>{$('modelMenu')?.classList.toggle('hidden')}); $('fastModelOption')?.addEventListener('click',()=>{$('modelMenu')?.classList.add('hidden');showToast('Zyqex Fast selected — your current AI connection is used.');});
    $('searchChatsBtn')?.addEventListener('click',()=>{const wrap=$('chatSearchWrap');wrap?.classList.toggle('hidden');if(!wrap?.classList.contains('hidden')){$('chatSearch')?.focus()}});
    $('chatSearch')?.addEventListener('input',e=>renderChatList(e.target.value)); $('clearChatSearch')?.addEventListener('click',()=>{$('chatSearch').value='';renderChatList();$('chatSearch').focus()});
    $('chatSortBtn')?.addEventListener('click',()=>showToast('Chats are sorted by most recent.'));
    $('brandHome')?.addEventListener('click',newChat);
    ['authModal','accountModal','settingsModal','premiumModal'].forEach(id=>$(id)?.addEventListener('click',e=>{if(e.target===$(id))closeModal(id)}));
    document.addEventListener('click',e=>{if(!e.target.closest('#attachBtn')&&!e.target.closest('#plusMenu'))$('plusMenu')?.classList.add('hidden');if(!e.target.closest('#modelBtn')&&!e.target.closest('#modelMenu'))$('modelMenu')?.classList.add('hidden')});
    if(localStorage.getItem('zyqex_light')==='true')document.body.classList.add('light');
    updateAccountUI(); showWelcome();
    const sb=getSupabase(); if(sb){sb.auth.getSession().then(async({data})=>{currentUser=data.session?.user||null;if(currentUser){await loadProfile();await loadChats()}else renderChatList()} ).catch(console.error);sb.auth.onAuthStateChange(async(_event,session)=>{currentUser=session?.user||null;if(currentUser){await loadProfile();await loadChats()}else{currentProfile=null;chatDataCache=[];renderChatList()}updateAccountUI()})}
  }

  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
